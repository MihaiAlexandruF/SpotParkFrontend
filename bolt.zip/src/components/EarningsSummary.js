import { useEffect, useState } from "react";
import { View, Text, StyleSheet, ActivityIndicator } from "react-native";
import api from "../services/api";

export default function EarningsSummary() {
  const [earnings, setEarnings] = useState([]);
  const [total, setTotal] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEarnings = async () => {
      try {
        const [perParkingRes, totalRes] = await Promise.all([
          api.get("/earnings/per-parking"),
          api.get("/earnings/total"),
        ]);
        setEarnings(perParkingRes.data);
        setTotal(totalRes.data.total);
      } catch (error) {
        console.error("❌ Eroare la fetch earnings:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchEarnings();
  }, []);

  if (loading) {
    return <ActivityIndicator size="small" color="#4CAF50" />;
  }

  const maxTotal = Math.max(...earnings.map(e => e.total || 0), 1);

  return (
    <View>
      <View style={styles.totalContainer}>
        <Text style={styles.totalLabel}>Total venituri</Text>
        <Text style={styles.totalValue}>{total} RON</Text>
      </View>

      {earnings.map((spot, idx) => (
        <View key={idx} style={styles.barContainer}>
          <View style={styles.barHeader}>
            <Text style={styles.barLabel}>{spot.name}</Text>
            <Text style={styles.barValue}>{spot.total} RON</Text>
          </View>
          <View style={styles.barWrapper}>
            <View
              style={[
                styles.bar,
                {
                  width: `${(spot.total / maxTotal) * 100}%`,
                  backgroundColor: spot.total > 0 ? "#4CAF50" : "#E0E0E0",
                },
              ]}
            />
          </View>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  totalContainer: {
    marginBottom: 20,
    alignItems: "center",
  },
  totalLabel: {
    fontSize: 14,
    color: "#999",
    fontFamily: "EuclidCircularB-Regular",
  },
  totalValue: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#FFFC00",
    fontFamily: "EuclidCircularB-Bold",
  },
  barContainer: {
    marginBottom: 16,
  },
  barHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  barLabel: {
    fontSize: 14,
    color: "#333",
    fontFamily: "EuclidCircularB-Medium",
  },
  barValue: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#4CAF50",
    fontFamily: "EuclidCircularB-Bold",
  },
  barWrapper: {
    height: 10,
    backgroundColor: "#F0F0F0",
    borderRadius: 5,
    overflow: "hidden",
  },
  bar: {
    height: "100%",
    borderRadius: 5,
  },
});
